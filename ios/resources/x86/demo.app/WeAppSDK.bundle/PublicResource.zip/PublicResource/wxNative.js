;var injectNativateRet = "ok";
if (typeof wx !== 'undefined') {
  if (typeof wxNative === 'undefined' && wx.getBaseMethods) {
    wxNative = function () {
      var _baseMethods = wx.getBaseMethods();

      var _invokeMethod = _baseMethods.invokeMethod;
      var _onMethod = _baseMethods.onMethod;

      var _openWCPayOverseaPaymentReceive = function (args) {
        _invokeMethod("openWCPayOverseaPaymentReceive", args);
      };

      var _handleWCPayOverseaWalletBuffer = function (args) {
        _invokeMethod("handleWCPayOverseaWalletBuffer", args);
      };
        
      var _handleMPChannelAction = function (args) {
        _invokeMethod("handleMPChannelAction", args);
      };
        
      var _createWebViewForFastLoad = function (args) {
        _invokeMethod("createWebViewForFastLoad", args);
      };
        
      var _downloadPageDataForFastLoad = function (args) {
        _invokeMethod("downloadPageDataForFastLoad", args);
      };
        
      var _openWebViewUseFastLoad = function (args) {
        _invokeMethod("openWebViewUseFastLoad", args);
      };

      var _shareFinderEndorsementToFriend = function (args) {
        _invokeMethod("shareFinderEndorsementToFriend", args);
      }

      var _openFinderProfile = function (args) {
        _invokeMethod("openFinderProfile", args);
      }

      var _endorsementFinished = function (args) {
        _invokeMethod("endorsementFinished", args);
      }
        
      var _kvReport = function (args) {
        _invokeMethod("kvReport", args);
      }

      function transWxmlToHtml(url) {
        if (typeof url !== 'string') {
          return url;
        } else {
          var path = url.split('?')[0];
          var query = url.split('?')[1];
          path += '.html';

          if (typeof query !== 'undefined') {
            return path + "?" + query;
          } else {
            return path;
          }
        }
      }
      
      var _navigateToMiniProgram = function (args) {
        if (args.path) {
            args.path = transWxmlToHtml(args.path);
        }
        _invokeMethod("navigateToMiniProgram", args);
      };

      var _onWxNativeEvent = function (callback) {
        _onMethod('onWxNativeEvent', callback);
      };
        
      var _onUpdateChannelFeedsEvent = function (callback) {
        _onMethod('onUpdateChannelFeeds', callback);
      };
        
      /**** Add JsApi Here ****/

      var methodsList = {
        openWCPayOverseaPaymentReceive: _openWCPayOverseaPaymentReceive,
        handleWCPayOverseaWalletBuffer: _handleWCPayOverseaWalletBuffer,
        navigateToMiniProgram: _navigateToMiniProgram,
        createWebViewForFastLoad: _createWebViewForFastLoad,
        downloadPageDataForFastLoad: _downloadPageDataForFastLoad,
        openWebViewUseFastLoad: _openWebViewUseFastLoad,
        handleMPChannelAction: _handleMPChannelAction,
        shareFinderEndorsementToFriend : _shareFinderEndorsementToFriend,
        openFinderProfile : _openFinderProfile,
        endorsementFinished : _endorsementFinished,
        kvReport : _kvReport
      };
      /**** Add JsApiEvent Here ****/

      var eventList = {
        onWxNativeEvent: _onWxNativeEvent,
        onUpdateChannelFeedsEvent: _onUpdateChannelFeedsEvent
      };
      /**** canIUse ****/

      var canIUse = function canIUse(name) {
        name = name || ''
        return !!methodsList[name];
      };

      return Object.assign({
        canIUse: canIUse
      }, methodsList, eventList);
    }();
    injectNativateRet = "ok"
  } else {
    injectNativateRet = "fail:init wxNative fail, already init"
  }
} else {
  injectNativateRet = "fail:init wxNative fail, wx is null"
}

injectNativateRet
